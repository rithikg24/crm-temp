# CRM Database Initialization Setup

## Overview
This setup automatically populates the H2 in-memory database with realistic dummy data every time the application starts, eliminating the need to manually add test data after each restart.

## Files Created

### 1. `src/main/resources/schema.sql`
- **Purpose**: Defines the database schema with proper table creation order
- **Features**:
  - Drops existing tables for clean restart
  - Creates tables in dependency order (customer → lead → interaction)
  - Includes foreign key constraints
  - Uses AUTO_INCREMENT for primary keys

### 2. `src/main/resources/data.sql`
- **Purpose**: Populates tables with realistic dummy data
- **Data Included**:
  - **8 Customers**: Mix of Individual and Business types
  - **10 Leads**: Various sources, statuses, and topics
  - **20 Interactions**: Different types, topics, and detailed notes

### 3. Updated `application.properties`
- **Configuration**: Enables SQL script execution on startup
- **Settings**:
  - `spring.sql.init.mode=always` - Always run scripts
  - `spring.sql.init.continue-on-error=true` - Continue if errors occur
  - `spring.jpa.hibernate.ddl-auto=none` - Disable Hibernate DDL

## Sample Data Details

### Customers (8 records)
- **Individual Customers**: John Smith, Michael Brown, David Wilson, Robert Taylor
- **Business Customers**: Sarah Johnson (TechCorp), Emily Davis (Innovate), Lisa Anderson (GlobalCorp), Jennifer Martinez (Startup)
- **Realistic Data**: Real addresses, phone numbers, email addresses

### Leads (10 records)
- **Sources**: Website, Referral, Cold Call, Email Campaign, Social Media, Trade Show
- **Statuses**: New, Qualified, Contacted, Proposal Sent, Negotiation, Closed Won
- **Topics**: Product Inquiry, Enterprise Solution, Service Upgrade, Partnership Opportunity, etc.

### Interactions (20 records)
- **Types**: Phone Call, Email, Meeting, Video Call
- **Topics**: Initial Contact, Follow-up, Product Demo, Pricing Discussion, Technical Questions, etc.
- **Timeline**: Spread across 10 days (Jan 15-24, 2024)
- **Realistic Notes**: Detailed interaction summaries

## Benefits

### 1. **Development Efficiency**
- No need to manually add test data after each restart
- Consistent data for testing and development
- Immediate access to realistic scenarios

### 2. **Testing Support**
- Pre-populated data for integration tests
- Various customer types and lead statuses
- Rich interaction history for testing features

### 3. **Demo Ready**
- Application is immediately usable for demonstrations
- Shows realistic CRM functionality
- Professional-looking data for presentations

## Usage

### Starting the Application
```bash
mvn spring-boot:run
```

The application will:
1. Start H2 in-memory database
2. Execute `schema.sql` to create tables
3. Execute `data.sql` to populate data
4. Start the web application with pre-loaded data

### Accessing Data
- **Dashboard**: Shows statistics from pre-loaded data
- **Customers**: View all 8 customers with their details
- **Leads**: Browse 10 leads with various statuses
- **Interactions**: See 20 interactions across customers
- **Analytics**: Charts populated with realistic data

### H2 Console
Access the H2 console at: `http://localhost:8080/h2-console`
- **JDBC URL**: `jdbc:h2:mem:test`
- **Username**: `sa`
- **Password**: (leave empty)

## Customization

### Adding More Data
Edit `src/main/resources/data.sql` to add more records:
```sql
INSERT INTO customer (id, name, email_id, contact_number, address, customer_type) VALUES 
(9, 'New Customer', 'new@email.com', '+1-555-0109', 'New Address', 'Individual');
```

### Modifying Schema
Edit `src/main/resources/schema.sql` to change table structure:
```sql
ALTER TABLE customer ADD COLUMN company_name VARCHAR(255);
```

### Disabling Data Initialization
Set in `application.properties`:
```properties
spring.sql.init.mode=never
```

## Troubleshooting

### Common Issues
1. **Foreign Key Violations**: Ensure data is inserted in dependency order
2. **Duplicate Keys**: Check for ID conflicts in data.sql
3. **Syntax Errors**: Validate SQL syntax in both schema.sql and data.sql

### Debugging
- Check application logs for SQL execution messages
- Use H2 console to verify data insertion
- Enable SQL logging: `spring.jpa.show-sql=true`

## Data Relationships

### Customer → Lead
- Each customer can have multiple leads
- Leads reference customer via `customer_id`

### Customer → Interaction
- Each customer can have multiple interactions
- Interactions reference customer via `customer_id`

### Sample Relationships
- **John Smith (ID: 1)**: 2 leads, 3 interactions
- **Sarah Johnson (ID: 2)**: 1 lead, 2 interactions
- **Michael Brown (ID: 3)**: 2 leads, 3 interactions

This setup provides a complete, realistic CRM environment ready for development, testing, and demonstration purposes.
