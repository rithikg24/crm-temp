package com.example.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Interaction;
import com.example.crm.service.CustomerService;
import com.example.crm.service.InteractionService;

@Controller
public class InteractionController {

    @Autowired
    InteractionService interactionService;
    @Autowired
    CustomerService customerService;


    @GetMapping("/interactions/customers/{id}")
    public ModelAndView getInteractionsByCustomerId(@PathVariable Long id){
        ModelAndView mav = new ModelAndView("customer-interactions-list");
        Customer customerInfo = customerService.getCustomerById(id);
        System.out.println("InteractionController - Getting interactions for customer ID: " + id);
        System.out.println("Customer found: " + (customerInfo != null ? customerInfo.getName() : "null"));
        
        if (customerInfo == null) {
            System.out.println("Customer not found with ID: " + id);
            mav = new ModelAndView("error");
            mav.addObject("error", "Customer not found with ID: " + id);
            return mav;
        }
        
        List<Interaction> interactionsList = interactionService.getInteractionsByCustomerId(id);
        System.out.println("Found " + interactionsList.size() + " interactions for customer ID: " + id);
        for (Interaction interaction : interactionsList) {
            System.out.println("Interaction ID: " + interaction.getId() + ", Type: " + interaction.getType() + ", Topic: " + interaction.getTopic() + ", Time: " + interaction.getTime());
        }
        
        mav.addObject("customerInfo",customerInfo);
        mav.addObject("interactionList",interactionsList);
        return mav;
    }

    @GetMapping("/interactions/customer/{id}/add")
    public ModelAndView showAddInteractionForm(@PathVariable Long id){
        ModelAndView mav = new ModelAndView("add-interaction");
        Customer customerInfo = customerService.getCustomerById(id);
        System.out.println("InteractionController - Getting add interaction form for customer ID: " + id);
        System.out.println("Customer found: " + (customerInfo != null ? customerInfo.getName() : "null"));
        
        if (customerInfo == null) {
            System.out.println("Customer not found with ID: " + id);
            mav = new ModelAndView("error");
            mav.addObject("error", "Customer not found with ID: " + id);
            return mav;
        }
        
        Interaction interaction = new Interaction();
        interaction.setCustomerId(id);
        mav.addObject("customerInfo", customerInfo);
        mav.addObject("interaction", interaction);
        return mav;
    }

    @PostMapping("/interactions/customers/{id}")
    public String addInteraction(@PathVariable Long id, @ModelAttribute Interaction interaction){
        System.out.println("InteractionController - Adding interaction for customer ID: " + id);
        System.out.println("Interaction type: " + interaction.getType());
        System.out.println("Interaction topic: " + interaction.getTopic());
        System.out.println("Interaction notes: " + interaction.getNotes());
        System.out.println("Interaction time before save: " + interaction.getTime());
        
        interaction.setCustomerId(id);
        Interaction savedInteraction = interactionService.addInteraction(interaction);
        
        System.out.println("Interaction saved with ID: " + savedInteraction.getId());
        System.out.println("Interaction time after save: " + savedInteraction.getTime());
        
        return "redirect:/interactions/customers/" + id;
    }
}
