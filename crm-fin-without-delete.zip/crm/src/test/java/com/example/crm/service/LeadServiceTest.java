package com.example.crm.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Lead;
import com.example.crm.repository.CustomerRepository;
import com.example.crm.repository.LeadRepository;

@ExtendWith(MockitoExtension.class)
class LeadServiceTest {

    @Mock
    private LeadRepository leadRepository;

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private LeadService leadService;

    private Lead testLead;

    @BeforeEach
    void setUp() {
        testLead = new Lead();
        testLead.setId(1L);
        testLead.setCustomerId(1L);
        testLead.setSource("Website");
        testLead.setStatus("New");
        testLead.setTopic("Product Inquiry");
        testLead.setNotes("Customer interested in our product");
    }

    @Test
    void getAllLeads_ShouldReturnAllLeads() {
        // Given
        List<Lead> expectedLeads = Arrays.asList(testLead);
        when(leadRepository.findAll()).thenReturn(expectedLeads);

        // When
        List<Lead> actualLeads = leadService.getAllLeads();

        // Then
        assertEquals(1, actualLeads.size());
        assertEquals("Website", actualLeads.get(0).getSource());
        verify(leadRepository).findAll();
    }

    @Test
    void getLeadById_WhenLeadExists_ShouldReturnLead() {
        // Given
        when(leadRepository.findById(1L)).thenReturn(Optional.of(testLead));

        // When
        Lead actualLead = leadService.getLeadById(1L);

        // Then
        assertNotNull(actualLead);
        assertEquals("Website", actualLead.getSource());
        verify(leadRepository).findById(1L);
    }

    @Test
    void getLeadById_WhenLeadDoesNotExist_ShouldReturnNull() {
        // Given
        when(leadRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Lead actualLead = leadService.getLeadById(999L);

        // Then
        assertNull(actualLead);
        verify(leadRepository).findById(999L);
    }

    @Test
    void addLead_ShouldSaveLead() {
        // Given
        when(leadRepository.save(any(Lead.class))).thenReturn(testLead);

        // When
        leadService.addLead(testLead);

        // Then
        verify(leadRepository).save(testLead);
    }

    @Test
    void updateLead_ShouldUpdateLead() {
        // Given
        when(leadRepository.save(any(Lead.class))).thenReturn(testLead);

        // When
        leadService.updateLead(testLead);

        // Then
        verify(leadRepository).save(testLead);
    }

    @Test
    void deleteLead_WhenLeadExists_ShouldDeleteLead() {
        // Given
        when(leadRepository.existsById(1L)).thenReturn(true);

        // When
        leadService.deleteLead(1L);

        // Then
        verify(leadRepository).existsById(1L);
        verify(leadRepository).deleteById(1L);
    }

    @Test
    void deleteLead_WhenLeadDoesNotExist_ShouldNotDelete() {
        // Given
        when(leadRepository.existsById(999L)).thenReturn(false);

        // When
        leadService.deleteLead(999L);

        // Then
        verify(leadRepository).existsById(999L);
        verify(leadRepository, never()).deleteById(any());
    }

    @Test
    void getLeadsByCustomerId_ShouldReturnLeadsForCustomer() {
        // Given
        List<Lead> expectedLeads = Arrays.asList(testLead);
        when(leadRepository.findByCustomerId(1L)).thenReturn(expectedLeads);

        // When
        List<Lead> actualLeads = leadService.getLeadsByCustomerId(1L);

        // Then
        assertEquals(1, actualLeads.size());
        assertEquals(1L, actualLeads.get(0).getCustomerId());
        verify(leadRepository).findByCustomerId(1L);
    }

    @Test
    void getCustomerById_WhenCustomerExists_ShouldReturnCustomer() {
        // Given
        Customer testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("Test Customer");
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));

        // When
        Customer actualCustomer = leadService.getCustomerById(1L);

        // Then
        assertNotNull(actualCustomer);
        assertEquals("Test Customer", actualCustomer.getName());
        verify(customerRepository).findById(1L);
    }

    @Test
    void getCustomerById_WhenCustomerDoesNotExist_ShouldReturnNull() {
        // Given
        when(customerRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Customer actualCustomer = leadService.getCustomerById(999L);

        // Then
        assertNull(actualCustomer);
        verify(customerRepository).findById(999L);
    }

    @Test
    void addCustomer_ShouldSaveAndReturnCustomer() {
        // Given
        Customer testCustomer = new Customer();
        testCustomer.setName("Test Customer");
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // When
        Customer savedCustomer = leadService.addCustomer(testCustomer);

        // Then
        assertNotNull(savedCustomer);
        assertEquals("Test Customer", savedCustomer.getName());
        verify(customerRepository).save(testCustomer);
    }
}
