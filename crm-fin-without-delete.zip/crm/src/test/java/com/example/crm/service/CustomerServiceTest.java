package com.example.crm.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.crm.entity.Customer;
import com.example.crm.repository.CustomerRepository;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    private Customer testCustomer;

    @BeforeEach
    void setUp() {
        testCustomer = new Customer();
        testCustomer.setId(1L);
        testCustomer.setName("John Doe");
        testCustomer.setEmailId("john@example.com");
        testCustomer.setContactNumber("1234567890");
        testCustomer.setAddress("123 Main St");
        testCustomer.setCustomerType("Individual");
    }

    @Test
    void getAllCustomers_ShouldReturnAllCustomers() {
        // Given
        List<Customer> expectedCustomers = Arrays.asList(testCustomer);
        when(customerRepository.findAll()).thenReturn(expectedCustomers);

        // When
        List<Customer> actualCustomers = customerService.getAllCustomers();

        // Then
        assertEquals(1, actualCustomers.size());
        assertEquals("John Doe", actualCustomers.get(0).getName());
        verify(customerRepository).findAll();
    }

    @Test
    void getCustomerById_WhenCustomerExists_ShouldReturnCustomer() {
        // Given
        when(customerRepository.findById(1L)).thenReturn(Optional.of(testCustomer));

        // When
        Customer actualCustomer = customerService.getCustomerById(1L);

        // Then
        assertNotNull(actualCustomer);
        assertEquals("John Doe", actualCustomer.getName());
        verify(customerRepository).findById(1L);
    }

    @Test
    void getCustomerById_WhenCustomerDoesNotExist_ShouldReturnNull() {
        // Given
        when(customerRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Customer actualCustomer = customerService.getCustomerById(999L);

        // Then
        assertNull(actualCustomer);
        verify(customerRepository).findById(999L);
    }

    @Test
    void addCustomer_ShouldSaveCustomer() {
        // Given
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // When
        customerService.addCustomer(testCustomer);

        // Then
        verify(customerRepository).save(testCustomer);
    }

    @Test
    void updateCustomer_ShouldUpdateCustomer() {
        // Given
        when(customerRepository.save(any(Customer.class))).thenReturn(testCustomer);

        // When
        customerService.updateCustomer(testCustomer);

        // Then
        verify(customerRepository).save(testCustomer);
    }

    @Test
    void deleteCustomer_WhenCustomerExists_ShouldDeleteCustomer() {
        // Given
        when(customerRepository.existsById(1L)).thenReturn(true);

        // When
        customerService.deleteCustomer(1L);

        // Then
        verify(customerRepository).existsById(1L);
        verify(customerRepository).deleteById(1L);
    }

    @Test
    void deleteCustomer_WhenCustomerDoesNotExist_ShouldNotDelete() {
        // Given
        when(customerRepository.existsById(999L)).thenReturn(false);

        // When
        customerService.deleteCustomer(999L);

        // Then
        verify(customerRepository).existsById(999L);
        verify(customerRepository, never()).deleteById(any());
    }
}
