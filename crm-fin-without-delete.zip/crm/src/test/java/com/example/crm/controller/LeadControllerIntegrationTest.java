package com.example.crm.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@AutoConfigureWebMvc
@ActiveProfiles("test")
@Transactional
@Rollback(false)
class LeadControllerIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void getAllLeads_ShouldReturnLeadsListView() throws Exception {
        mockMvc.perform(get("/leads"))
                .andExpect(status().isOk())
                .andExpect(view().name("leads-list"))
                .andExpect(model().attributeExists("leadWithCustomerList"));
    }

    @Test
    void showAddLeadForm_ShouldReturnAddLeadView() throws Exception {
        mockMvc.perform(get("/leads/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("add-lead"))
                .andExpect(model().attributeExists("customerList"))
                .andExpect(model().attributeExists("lead"))
                .andExpect(model().attributeExists("customer"));
    }

    @Test
    void showUpdateLeadForm_WhenLeadExists_ShouldReturnUpdateLeadView() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create a lead
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "Customer interested in product"));

        // Then try to update the lead
        mockMvc.perform(get("/leads/1/edit"))
                .andExpect(status().isOk())
                .andExpect(view().name("update-lead"))
                .andExpect(model().attributeExists("lead"))
                .andExpect(model().attributeExists("customer"));
    }

    @Test
    void addLead_WithNewCustomer_ShouldRedirectToLeads() throws Exception {
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "new")
                .param("customerName", "New Customer")
                .param("customerEmail", "new@example.com")
                .param("customerContact", "1234567890")
                .param("customerAddress", "New Address")
                .param("customerCustomerType", "Individual")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "New customer inquiry"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/leads"));
    }

    @Test
    void addLead_WithExistingCustomer_ShouldRedirectToLeads() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create a lead for existing customer
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Referral")
                .param("status", "Contacted")
                .param("topic", "Service Inquiry")
                .param("notes", "Existing customer inquiry"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/leads"));
    }

    @Test
    void updateLead_WithValidData_ShouldRedirectToLeads() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create a lead
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "Customer interested in product"));

        // Then update the lead
        mockMvc.perform(post("/leads/1")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("source", "Website")
                .param("status", "Qualified")
                .param("topic", "Product Inquiry")
                .param("notes", "Updated notes"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/leads"));
    }

    @Test
    void deleteLead_ShouldRedirectToLeads() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create a lead
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "Customer interested in product"));

        // Then delete the lead
        mockMvc.perform(delete("/leads/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/leads"));
    }
}
