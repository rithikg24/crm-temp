package com.example.crm.service;

import com.example.crm.entity.Interaction;
import com.example.crm.repository.InteractionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class InteractionService {

    @Autowired
    InteractionRepository interactionRepository;

    public List<Interaction> getAllInteractions(){
        return interactionRepository.findAll();
    }

    public void addInteraction(Interaction i){
        interactionRepository.save(i);
    }

    public Interaction getInteractionById(Long id){
        return interactionRepository.findById(id).orElse(null);
    }

    public List<Interaction> getInteractionsByCustomerId(Long customerId){
        return interactionRepository.findByCustomerId(customerId);
    }

    public void deleteInteractionsByCustomerId(Long id){
        interactionRepository.deleteByCustomerId(id);
    }
}
