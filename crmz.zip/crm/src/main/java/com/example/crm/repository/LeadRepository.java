package com.example.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.crm.entity.Lead;

public interface LeadRepository extends JpaRepository<Lead, Long> {
    List<Lead> findByCustomerId(Long customerId);
}
