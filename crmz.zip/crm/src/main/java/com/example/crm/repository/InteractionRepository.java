package com.example.crm.repository;

import com.example.crm.entity.Interaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InteractionRepository extends JpaRepository<Interaction,Long> {
    List<Interaction> findByCustomerId(Long customerId);
    void deleteByCustomerId(Long customerId);
}
