package com.example.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Lead;
import com.example.crm.service.CustomerService;
import com.example.crm.service.LeadService;

@Controller
public class LeadController {

    // Inner class to hold lead with customer data
    public static class LeadWithCustomer {
        private Lead lead;
        private Customer customer;
        
        public LeadWithCustomer(Lead lead, Customer customer) {
            this.lead = lead;
            this.customer = customer;
        }
        
        public Lead getLead() { return lead; }
        public Customer getCustomer() { return customer; }
    }

    @Autowired
    LeadService leadService;
    
    @Autowired
    CustomerService customerService;

    @GetMapping("/leads")
    public ModelAndView getAllLeads() {
        ModelAndView mav = new ModelAndView("leads-list");
        List<Lead> leadList = leadService.getAllLeads();
        
        // Create a list of lead data with customer information
        List<LeadWithCustomer> leadWithCustomerList = leadList.stream()
            .map(lead -> {
                Customer customer = leadService.getCustomerById(lead.getCustomerId());
                return new LeadWithCustomer(lead, customer);
            })
            .collect(java.util.stream.Collectors.toList());
            
        mav.addObject("leadWithCustomerList", leadWithCustomerList);
        return mav;
    }

    @GetMapping("/leads/add")
    public ModelAndView showAddLeadForm() {
        try {
            ModelAndView mav = new ModelAndView("add-lead");
            List<Customer> customerList = customerService.getAllCustomers();
            mav.addObject("customerList", customerList);
            mav.addObject("lead", new Lead());
            mav.addObject("customer", new Customer());
            return mav;
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView errorMav = new ModelAndView("error");
            errorMav.addObject("error", "Failed to load add lead form: " + e.getMessage());
            return errorMav;
        }
    }

    @PostMapping("/leads")
    public String addLead(@ModelAttribute Lead lead, 
                         @RequestParam(required = false) String customerType,
                         @RequestParam(required = false) Long customerId,
                         @RequestParam(required = false) String customerName,
                         @RequestParam(required = false) String customerEmail,
                         @RequestParam(required = false) String customerContact,
                         @RequestParam(required = false) String customerAddress,
                         @RequestParam(required = false) String customerCustomerType) {
        
        try {
            System.out.println("LeadController - Received data:");
            System.out.println("Customer Type: " + customerType);
            System.out.println("Customer ID: " + customerId);
            System.out.println("Customer Name: " + customerName);
            System.out.println("Customer Email: " + customerEmail);
            System.out.println("Customer Contact: " + customerContact);
            System.out.println("Customer Address: " + customerAddress);
            System.out.println("Customer Customer Type: " + customerCustomerType);
            System.out.println("Lead Source: " + lead.getSource());
            System.out.println("Lead Status: " + lead.getStatus());
            System.out.println("Lead Topic: " + lead.getTopic());
            System.out.println("Lead Notes: " + lead.getNotes());
            
            if ("new".equals(customerType)) {
                // Create new customer from individual parameters
                Customer newCustomer = new Customer();
                newCustomer.setName(customerName);
                newCustomer.setEmailId(customerEmail);
                newCustomer.setContactNumber(customerContact);
                newCustomer.setAddress(customerAddress);
                newCustomer.setCustomerType(customerCustomerType);
                
                System.out.println("Creating new customer: " + newCustomer.getName());
                
                // Save new customer first
                Customer savedCustomer = leadService.addCustomer(newCustomer);
                lead.setCustomerId(savedCustomer.getId());
                
                System.out.println("Saved customer with ID: " + savedCustomer.getId());
            } else if ("existing".equals(customerType) && customerId != null) {
                // Use existing customer ID
                lead.setCustomerId(customerId);
                System.out.println("Using existing customer ID: " + customerId);
            } else {
                // Handle case where no valid customer type is selected
                System.out.println("Invalid customer type or missing customer ID");
                return "redirect:/leads/add?error=invalid_customer_type";
            }
            
            System.out.println("Saving lead with customer ID: " + lead.getCustomerId());
            leadService.addLead(lead);
            return "redirect:/leads";
        } catch (Exception e) {
            // Log the error and redirect back to form
            System.out.println("Error in addLead: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/leads/add?error=save_failed";
        }
    }

    @GetMapping("/leads/{id}")
    public Lead getLead(@PathVariable Long id) {
        return leadService.getLeadById(id);
    }

    @GetMapping("/leads/{id}/edit")
    public ModelAndView showUpdateLeadForm(@PathVariable Long id) {
        try {
            ModelAndView mav = new ModelAndView("update-lead");
            Lead lead = leadService.getLeadById(id);
            if (lead == null) {
                mav = new ModelAndView("error");
                mav.addObject("error", "Lead not found with ID: " + id);
                return mav;
            }
            
            // Get customer information
            Customer customer = leadService.getCustomerById(lead.getCustomerId());
            
            mav.addObject("lead", lead);
            mav.addObject("customer", customer);
            return mav;
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView errorMav = new ModelAndView("error");
            errorMav.addObject("error", "Failed to load update lead form: " + e.getMessage());
            return errorMav;
        }
    }

    @PostMapping("/leads/{id}")
    public String updateLead(@PathVariable Long id, @ModelAttribute Lead lead) {
        try {
            System.out.println("LeadController - Updating lead with ID: " + id);
            System.out.println("Lead Source: " + lead.getSource());
            System.out.println("Lead Status: " + lead.getStatus());
            System.out.println("Lead Topic: " + lead.getTopic());
            System.out.println("Lead Notes: " + lead.getNotes());
            
            // Get the existing lead to preserve customerId
            Lead existingLead = leadService.getLeadById(id);
            if (existingLead == null) {
                System.out.println("Lead not found with ID: " + id);
                return "redirect:/leads?error=lead_not_found";
            }
            
            // Update only the lead fields, preserve customerId
            lead.setId(id);
            lead.setCustomerId(existingLead.getCustomerId());
            
            leadService.updateLead(lead);
            System.out.println("Lead updated successfully");
            return "redirect:/leads";
        } catch (Exception e) {
            System.out.println("Error updating lead: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/leads?error=update_failed";
        }
    }

    @DeleteMapping("/leads/{id}")
    public String deleteLead(@PathVariable Long id) {
        leadService.deleteLead(id);
        return "redirect:/leads";
    }
}
