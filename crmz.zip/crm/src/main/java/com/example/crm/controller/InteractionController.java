package com.example.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.ModelAndView;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Interaction;
import com.example.crm.service.CustomerService;
import com.example.crm.service.InteractionService;

@Controller
public class InteractionController {

    @Autowired
    InteractionService interactionService;
    @Autowired
    CustomerService customerService;

    @GetMapping("/interactions")
    @ResponseBody
    public List<Interaction> getInteractions(){
        return interactionService.getAllInteractions();
    }

    @PostMapping("/interactions")
    @ResponseBody
    public void addInteraction(@RequestBody Interaction i){
        interactionService.addInteraction(i);
    }

    @GetMapping("/interactions/{id}")
    @ResponseBody
    public Interaction getInteraction(@PathVariable Long id){
        Interaction i = interactionService.getInteractionById(id);
        if(i==null) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        return i;
    }

    @GetMapping("/interactions/customers/{id}")
    public ModelAndView getInteractionsByCustomerId(@PathVariable Long id){
        ModelAndView mav = new ModelAndView("customer-interactions-list");
        Customer customerInfo = customerService.getCustomerById(id);
        List<Interaction> interactionsList = interactionService.getInteractionsByCustomerId(id);
        mav.addObject("customerInfo",customerInfo);
        mav.addObject("interactionList",interactionsList);
        return mav;
    }

    @GetMapping("/interactions/customer/{id}/add")
    public ModelAndView showAddInteractionForm(@PathVariable Long id){
        ModelAndView mav = new ModelAndView("add-interaction");
        Customer customerInfo = customerService.getCustomerById(id);
        Interaction interaction = new Interaction();
        interaction.setCustomerId(id);
        mav.addObject("customerInfo", customerInfo);
        mav.addObject("interaction", interaction);
        return mav;
    }

    @PostMapping("/interactions/customers/{id}")
    public String addInteraction(@PathVariable Long id, @ModelAttribute Interaction interaction){
        interaction.setCustomerId(id);
        interactionService.addInteraction(interaction);
        return "redirect:/interactions/customers/" + id;
    }
}
