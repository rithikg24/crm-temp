package com.example.crm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Lead;
import com.example.crm.service.CustomerService;
import com.example.crm.service.LeadService;

@Controller
public class AnalyticsController {

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private LeadService leadService;

    @GetMapping("/analytics")
    public String analytics() {
        return "analytics";
    }

    @GetMapping("/api/analytics/customers-over-time")
    @ResponseBody
    public Map<String, Object> getCustomersOverTime() {
        // For demo purposes, we'll simulate data over time
        // In a real application, you'd query with date ranges
        List<Customer> customers = customerService.getAllCustomers();
        
        // Simulate growth over time (this is simplified - in reality you'd group by creation date)
        int totalCustomers = customers.size();
        int[] customerCounts = new int[12]; // 12 months
        for (int i = 0; i < 12; i++) {
            customerCounts[i] = (int) (totalCustomers * (i + 1) / 12.0);
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("labels", new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                                         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"});
        result.put("data", customerCounts);
        return result;
    }

    @GetMapping("/api/analytics/leads-over-time")
    @ResponseBody
    public Map<String, Object> getLeadsOverTime() {
        List<Lead> leads = leadService.getAllLeads();
        
        // Simulate growth over time
        int totalLeads = leads.size();
        int[] leadCounts = new int[12]; // 12 months
        for (int i = 0; i < 12; i++) {
            leadCounts[i] = (int) (totalLeads * (i + 1) / 12.0);
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("labels", new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                                         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"});
        result.put("data", leadCounts);
        return result;
    }

    @GetMapping("/api/analytics/customer-types")
    @ResponseBody
    public Map<String, Object> getCustomerTypes() {
        List<Customer> customers = customerService.getAllCustomers();
        
        Map<String, Long> customerTypeCounts = customers.stream()
            .collect(Collectors.groupingBy(
                Customer::getCustomerType,
                Collectors.counting()
            ));
        
        Map<String, Object> result = new HashMap<>();
        result.put("labels", customerTypeCounts.keySet().toArray());
        result.put("data", customerTypeCounts.values().toArray());
        return result;
    }

    @GetMapping("/api/analytics/lead-status")
    @ResponseBody
    public Map<String, Object> getLeadStatus() {
        List<Lead> leads = leadService.getAllLeads();
        
        long activeLeads = leads.stream()
            .filter(lead -> !"Closed Won".equals(lead.getStatus()) && !"Closed Lost".equals(lead.getStatus()))
            .count();
        
        long closedLeads = leads.size() - activeLeads;
        
        Map<String, Object> result = new HashMap<>();
        result.put("labels", new String[]{"Active Leads", "Closed Leads"});
        result.put("data", new Long[]{activeLeads, closedLeads});
        return result;
    }

    @GetMapping("/api/analytics/lead-sources")
    @ResponseBody
    public Map<String, Object> getLeadSources() {
        List<Lead> leads = leadService.getAllLeads();
        
        Map<String, Long> sourceCounts = leads.stream()
            .collect(Collectors.groupingBy(
                Lead::getSource,
                Collectors.counting()
            ));
        
        Map<String, Object> result = new HashMap<>();
        result.put("labels", sourceCounts.keySet().toArray());
        result.put("data", sourceCounts.values().toArray());
        return result;
    }
}
