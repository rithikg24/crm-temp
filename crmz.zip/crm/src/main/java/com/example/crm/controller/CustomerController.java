package com.example.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.ModelAndView;

import com.example.crm.entity.Customer;
import com.example.crm.service.CustomerService;
import com.example.crm.service.InteractionService;
import com.example.crm.service.LeadService;

@Controller
public class CustomerController {

    @Autowired
    CustomerService customerService;
    @Autowired
    InteractionService interactionService;
    @Autowired
    LeadService leadService;

    @GetMapping("/")
    public ModelAndView dashboard(){
        ModelAndView mav = new ModelAndView("dashboard");
        
        // Get total customers count
        List<Customer> allCustomers = customerService.getAllCustomers();
        int totalCustomers = allCustomers.size();
        
        // Get active leads count (status not "Closed Won" or "Closed Lost")
        List<com.example.crm.entity.Lead> allLeads = leadService.getAllLeads();
        long activeLeadsCount = allLeads.stream()
            .filter(lead -> !"Closed Won".equals(lead.getStatus()) && !"Closed Lost".equals(lead.getStatus()))
            .count();
        
        // Get recent leads (limit to 5 most recent)
        List<com.example.crm.entity.Lead> recentLeads = allLeads.stream()
            .sorted((l1, l2) -> Long.compare(l2.getId(), l1.getId())) // Sort by ID descending (most recent first)
            .limit(5)
            .collect(java.util.stream.Collectors.toList());
        
        // Create lead with customer data for recent leads
        List<com.example.crm.controller.LeadController.LeadWithCustomer> recentLeadsWithCustomer = recentLeads.stream()
            .map(lead -> {
                Customer customer = leadService.getCustomerById(lead.getCustomerId());
                return new com.example.crm.controller.LeadController.LeadWithCustomer(lead, customer);
            })
            .collect(java.util.stream.Collectors.toList());
        
        mav.addObject("totalCustomers", totalCustomers);
        mav.addObject("activeLeadsCount", activeLeadsCount);
        mav.addObject("recentLeadsWithCustomer", recentLeadsWithCustomer);
        
        return mav;
    }

    @GetMapping("/customers")
    public ModelAndView GetCustomers(){
        ModelAndView mav = new ModelAndView("customers-list");
        List<Customer> customerList = customerService.getAllCustomers();
        mav.addObject("customerList",customerList);
        return mav;
    }

    @GetMapping("/customers/add")
    public ModelAndView showAddCustomerForm(){
        ModelAndView mav = new ModelAndView("add-customer");
        mav.addObject("customer", new Customer());
        return mav;
    }

    @GetMapping("/customers/{id}")
    public Customer GetCustomer(@PathVariable Long id){
        Customer c = customerService.getCustomerById(id);
        if(c==null) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        return c;
    }

    @GetMapping("/customers/{id}/edit")
    public ModelAndView showUpdateCustomerForm(@PathVariable Long id) {
        try {
            ModelAndView mav = new ModelAndView("update-customer");
            Customer customer = customerService.getCustomerById(id);
            if (customer == null) {
                mav = new ModelAndView("error");
                mav.addObject("error", "Customer not found with ID: " + id);
                return mav;
            }
            mav.addObject("customer", customer);
            return mav;
        } catch (Exception e) {
            e.printStackTrace();
            ModelAndView errorMav = new ModelAndView("error");
            errorMav.addObject("error", "Failed to load update customer form: " + e.getMessage());
            return errorMav;
        }
    }

    @PostMapping("/customers")
    public String AddCustomer(@ModelAttribute Customer customer){
        customerService.addCustomer(customer);
        return "redirect:/customers";
    }

    @PostMapping("/customers/{id}")
    public String updateCustomer(@PathVariable Long id, @ModelAttribute Customer customer) {
        try {
            System.out.println("CustomerController - Updating customer with ID: " + id);
            System.out.println("Customer Name: " + customer.getName());
            System.out.println("Customer Email: " + customer.getEmailId());
            System.out.println("Customer Contact: " + customer.getContactNumber());
            System.out.println("Customer Address: " + customer.getAddress());
            System.out.println("Customer Type: " + customer.getCustomerType());
            
            // Get the existing customer to preserve ID
            Customer existingCustomer = customerService.getCustomerById(id);
            if (existingCustomer == null) {
                System.out.println("Customer not found with ID: " + id);
                return "redirect:/customers?error=customer_not_found";
            }
            
            // Update customer with new data
            customer.setId(id);
            
            customerService.updateCustomer(customer);
            System.out.println("Customer updated successfully");
            return "redirect:/customers";
        } catch (Exception e) {
            System.out.println("Error updating customer: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/customers?error=update_failed";
        }
    }

    @DeleteMapping("/customers/{id}")
    public String DeleteCustomer(@PathVariable Long id){
        customerService.deleteCustomer(id);
        interactionService.deleteInteractionsByCustomerId(id);
        return "redirect:/customers";
    }
}
