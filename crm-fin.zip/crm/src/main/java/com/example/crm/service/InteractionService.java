package com.example.crm.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.crm.entity.Interaction;
import com.example.crm.repository.InteractionRepository;


@Service
public class InteractionService {

    @Autowired
    InteractionRepository interactionRepository;

    public List<Interaction> getAllInteractions(){
        return interactionRepository.findAll();
    }

    public Interaction addInteraction(Interaction i){
        // Manually set timestamp if not already set
        if (i.getTime() == null) {
            i.setTime(LocalDateTime.now());
        }
        
        // Ensure ID is null for new entities
        i.setId(null);
        
        System.out.println("InteractionService - Saving interaction with time: " + i.getTime());
        System.out.println("InteractionService - Interaction ID before save: " + i.getId());
        
        Interaction savedInteraction = interactionRepository.save(i);
        
        System.out.println("InteractionService - Saved interaction with ID: " + savedInteraction.getId());
        System.out.println("InteractionService - Saved interaction time: " + savedInteraction.getTime());
        
        return savedInteraction;
    }

    public Interaction getInteractionById(Long id){
        return interactionRepository.findById(id).orElse(null);
    }

    public List<Interaction> getInteractionsByCustomerId(Long customerId){
        return interactionRepository.findByCustomerId(customerId);
    }

    @Transactional
    public void deleteInteractionsByCustomerId(Long id){
        interactionRepository.deleteByCustomerId(id);
    }
}
