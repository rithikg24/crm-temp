package com.example.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.crm.entity.Customer;
import com.example.crm.entity.Lead;
import com.example.crm.repository.CustomerRepository;
import com.example.crm.repository.LeadRepository;

@Service
public class LeadService {

    @Autowired
    LeadRepository leadRepository;
    
    @Autowired
    CustomerRepository customerRepository;

    public List<Lead> getAllLeads() {
        return leadRepository.findAll();
    }

    public Lead getLeadById(Long id) {
        return leadRepository.findById(id).orElse(null);
    }

    public void addLead(Lead lead) {
        leadRepository.save(lead);
    }

    public void updateLead(Lead lead) {
        leadRepository.save(lead);
    }

    public void deleteLead(Long id) {
        if (leadRepository.existsById(id)) {
            leadRepository.deleteById(id);
        }
    }

    @Transactional
    public void deleteLeadsByCustomerId(Long customerId) {
        leadRepository.deleteByCustomerId(customerId);
    }

    public List<Lead> getLeadsByCustomerId(Long customerId) {
        return leadRepository.findByCustomerId(customerId);
    }

    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }
}
