package com.example.crm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Lead {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private Long customerId;
    private String source;
    private String status;
    private String topic;
    private String notes;

    // Default constructor
    public Lead() {
    }

    // Constructor with all fields
    public Lead(Long id, Long customerId, String source, String status, String topic, String notes) {
        this.id = id;
        this.customerId = customerId;
        this.source = source;
        this.status = status;
        this.topic = topic;
        this.notes = notes;
    }

    // Constructor without id (for new leads)
    public Lead(Long customerId, String source, String status, String topic, String notes) {
        this.customerId = customerId;
        this.source = source;
        this.status = status;
        this.topic = topic;
        this.notes = notes;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
