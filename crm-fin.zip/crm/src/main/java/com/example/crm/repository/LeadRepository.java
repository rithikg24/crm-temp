package com.example.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.crm.entity.Lead;

public interface LeadRepository extends JpaRepository<Lead, Long> {
    List<Lead> findByCustomerId(Long customerId);
    
    @Modifying
    @Query("DELETE FROM Lead l WHERE l.customerId = :customerId")
    void deleteByCustomerId(@Param("customerId") Long customerId);
}
