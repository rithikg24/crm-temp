package com.example.crm.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.crm.entity.Customer;
import com.example.crm.repository.CustomerRepository;

@Service
public class CustomerService {

    CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> getAllCustomers(){
        return customerRepository.findAll();
    }

    public Customer getCustomerById(Long id){
        return customerRepository.findById(id).orElse(null);
    }

    public void addCustomer(Customer c){
        customerRepository.save(c);
    }

    public void updateCustomer(Customer c){
        customerRepository.save(c);
    }

    @Transactional
    public void deleteCustomer(Long id){
        if(customerRepository.existsById(id)){
            customerRepository.deleteById(id);
        }
    }
}
