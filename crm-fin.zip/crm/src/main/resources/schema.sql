-- Schema initialization for CRM System
-- This script ensures proper table creation order

-- Drop tables if they exist (for clean restart)
DROP TABLE IF EXISTS interaction;
DROP TABLE IF EXISTS lead;
DROP TABLE IF EXISTS customer;

-- Create tables in proper order (respecting foreign key dependencies)
CREATE TABLE customer (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email_id VARCHAR(255) NOT NULL,
    contact_number VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL,
    customer_type VARCHAR(50) NOT NULL
);

CREATE TABLE lead (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    source VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    notes TEXT,
    FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE
);

CREATE TABLE interaction (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    time TIMESTAMP NOT NULL,
    type VARCHAR(100) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    notes TEXT NOT NULL,
    customer_id BIGINT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE CASCADE
);

-- Sequences will auto-increment from 1, and new records will continue from where the initial data ends
