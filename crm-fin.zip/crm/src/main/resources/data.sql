-- CRM System Dummy Data
-- This script populates the database with realistic test data

-- Insert Customers (without explicit IDs to avoid conflicts)
INSERT INTO customer (name, email_id, contact_number, address, customer_type) VALUES 
('John Smith', 'john.smith@email.com', '+1-555-0101', '123 Main St, New York, NY 10001', 'Individual'),
('Sarah Johnson', 'sarah.johnson@techcorp.com', '+1-555-0102', '456 Oak Ave, San Francisco, CA 94102', 'Business'),
('Michael Brown', 'mike.brown@email.com', '+1-555-0103', '789 Pine Rd, Chicago, IL 60601', 'Individual'),
('Emily Davis', 'emily.davis@innovate.com', '+1-555-0104', '321 Elm St, Austin, TX 78701', 'Business'),
('David Wilson', 'david.wilson@email.com', '+1-555-0105', '654 Maple Dr, Seattle, WA 98101', 'Individual'),
('Lisa Anderson', 'lisa.anderson@globalcorp.com', '+1-555-0106', '987 Cedar Ln, Boston, MA 02101', 'Business'),
('Robert Taylor', 'robert.taylor@email.com', '+1-555-0107', '147 Birch St, Denver, CO 80201', 'Individual'),
('Jennifer Martinez', 'jennifer.martinez@startup.com', '+1-555-0108', '258 Spruce Ave, Miami, FL 33101', 'Business');

-- Insert Leads (using customer IDs 1-8)
INSERT INTO lead (customer_id, source, status, topic, notes) VALUES 
(1, 'Website', 'New', 'Product Inquiry', 'Interested in premium package features'),
(2, 'Referral', 'Qualified', 'Enterprise Solution', 'Looking for custom enterprise solution'),
(3, 'Cold Call', 'Contacted', 'Service Upgrade', 'Wants to upgrade current service plan'),
(4, 'Email Campaign', 'New', 'Partnership Opportunity', 'Interested in partnership discussions'),
(5, 'Social Media', 'Qualified', 'Mobile App Development', 'Needs mobile app development services'),
(6, 'Trade Show', 'Proposal Sent', 'Digital Transformation', 'Large enterprise digital transformation project'),
(7, 'Website', 'Negotiation', 'Cloud Migration', 'Ready to migrate to cloud infrastructure'),
(8, 'Referral', 'Closed Won', 'Startup Package', 'Successfully closed startup package deal'),
(1, 'Cold Call', 'New', 'Additional Services', 'Follow-up on previous inquiry'),
(3, 'Email Campaign', 'Qualified', 'Support Services', 'Interested in premium support package');

-- Insert Interactions (using customer IDs 1-8)
INSERT INTO interaction (time, type, topic, notes, customer_id) VALUES 
('2024-01-15 09:30:00', 'Phone Call', 'Initial Contact', 'First contact with customer. Discussed basic requirements and pricing.', 1),
('2024-01-15 14:20:00', 'Email', 'Follow-up', 'Sent product brochure and pricing information via email.', 1),
('2024-01-16 10:15:00', 'Meeting', 'Product Demo', 'Conducted product demonstration. Customer showed strong interest.', 2),
('2024-01-16 16:45:00', 'Phone Call', 'Pricing Discussion', 'Discussed pricing options and payment terms.', 2),
('2024-01-17 11:00:00', 'Video Call', 'Technical Questions', 'Answered technical questions about implementation.', 3),
('2024-01-17 15:30:00', 'Email', 'Proposal', 'Sent detailed proposal with timeline and deliverables.', 3),
('2024-01-18 09:00:00', 'Meeting', 'Contract Review', 'Reviewed contract terms and conditions.', 4),
('2024-01-18 13:15:00', 'Phone Call', 'Decision Follow-up', 'Followed up on contract decision. Customer needs more time.', 4),
('2024-01-19 10:30:00', 'Video Call', 'Implementation Planning', 'Discussed implementation timeline and resource requirements.', 5),
('2024-01-19 16:00:00', 'Email', 'Project Kickoff', 'Sent project kickoff documentation and next steps.', 5),
('2024-01-20 08:45:00', 'Phone Call', 'Status Update', 'Provided project status update and addressed concerns.', 6),
('2024-01-20 12:30:00', 'Meeting', 'Milestone Review', 'Conducted milestone review meeting. Project on track.', 6),
('2024-01-21 14:00:00', 'Video Call', 'Training Session', 'Conducted training session for new features.', 7),
('2024-01-21 17:30:00', 'Email', 'Training Materials', 'Sent training materials and documentation.', 7),
('2024-01-22 09:30:00', 'Phone Call', 'Renewal Discussion', 'Discussed contract renewal and additional services.', 8),
('2024-01-22 11:45:00', 'Meeting', 'Success Review', 'Conducted success review meeting. Customer very satisfied.', 8),
('2024-01-23 10:00:00', 'Email', 'New Feature Announcement', 'Announced new features and upcoming releases.', 1),
('2024-01-23 15:20:00', 'Phone Call', 'Feature Feedback', 'Collected feedback on new features from customer.', 2),
('2024-01-24 09:15:00', 'Video Call', 'Technical Support', 'Provided technical support for implementation issues.', 3),
('2024-01-24 14:45:00', 'Meeting', 'Quarterly Review', 'Conducted quarterly business review meeting.', 4);
