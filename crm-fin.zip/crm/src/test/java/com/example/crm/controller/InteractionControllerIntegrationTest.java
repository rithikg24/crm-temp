package com.example.crm.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@AutoConfigureWebMvc
@ActiveProfiles("test")
@Transactional
@Rollback(false)
class InteractionControllerIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void getInteractionsByCustomerId_ShouldReturnInteractionsListView() throws Exception {
        // First create a customer and verify it was created
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));

        // Verify customer was created by checking the customers list
        mockMvc.perform(get("/customers"))
                .andExpect(status().isOk())
                .andExpect(view().name("customers-list"))
                .andExpect(model().attributeExists("customerList"));

        // Then get interactions for the customer
        mockMvc.perform(get("/interactions/customers/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("customer-interactions-list"))
                .andExpect(model().attributeExists("customerInfo"))
                .andExpect(model().attributeExists("interactionList"));
    }

    @Test
    void showAddInteractionForm_ShouldReturnAddInteractionView() throws Exception {
        // First create a customer and verify it was created
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));

        // Verify customer was created by checking the customers list
        mockMvc.perform(get("/customers"))
                .andExpect(status().isOk())
                .andExpect(view().name("customers-list"))
                .andExpect(model().attributeExists("customerList"));

        // Then get the add interaction form
        mockMvc.perform(get("/interactions/customer/1/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("add-interaction"))
                .andExpect(model().attributeExists("customerInfo"))
                .andExpect(model().attributeExists("interaction"));
    }

    @Test
    void addInteraction_WithValidData_ShouldRedirectToInteractions() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then add an interaction
        mockMvc.perform(post("/interactions/customers/1")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("type", "Call")
                .param("topic", "Product Inquiry")
                .param("notes", "Initial customer call"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/interactions/customers/1"));
    }
}
