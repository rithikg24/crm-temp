package com.example.crm.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@AutoConfigureWebMvc
@ActiveProfiles("test")
@Transactional
@Rollback(false)
class CustomerControllerIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void contextLoads() {
        // This test ensures that the Spring context loads successfully with MockMvc
        assertNotNull(mockMvc);
    }

    @Test
    void dashboard_ShouldReturnDashboardView() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(model().attributeExists("totalCustomers"))
                .andExpect(model().attributeExists("activeLeadsCount"))
                .andExpect(model().attributeExists("recentLeadsWithCustomer"));
    }

    @Test
    void getCustomers_ShouldReturnCustomersListView() throws Exception {
        mockMvc.perform(get("/customers"))
                .andExpect(status().isOk())
                .andExpect(view().name("customers-list"))
                .andExpect(model().attributeExists("customerList"));
    }

    @Test
    void showAddCustomerForm_ShouldReturnAddCustomerView() throws Exception {
        mockMvc.perform(get("/customers/add"))
                .andExpect(status().isOk())
                .andExpect(view().name("add-customer"))
                .andExpect(model().attributeExists("customer"));
    }

    @Test
    void showUpdateCustomerForm_WhenCustomerExists_ShouldReturnUpdateCustomerView() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));

        // Then try to update it - use a more flexible approach
        mockMvc.perform(get("/customers/1/edit"))
                .andExpect(status().isOk())
                .andExpect(view().name("update-customer"))
                .andExpect(model().attributeExists("customer"));
    }

    @Test
    void addCustomer_WithValidData_ShouldRedirectToCustomers() throws Exception {
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));
    }

    @Test
    void updateCustomer_WithValidData_ShouldRedirectToCustomers() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then update it
        mockMvc.perform(post("/customers/1")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Updated Customer")
                .param("emailId", "updated@example.com")
                .param("contactNumber", "0987654321")
                .param("address", "Updated Address")
                .param("customerType", "Business"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));
    }

    @Test
    void deleteCustomer_ShouldRedirectToCustomers() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then delete it
        mockMvc.perform(delete("/customers/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/customers"));
    }
}
