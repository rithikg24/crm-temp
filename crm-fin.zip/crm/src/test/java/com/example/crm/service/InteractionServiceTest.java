package com.example.crm.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.crm.entity.Interaction;
import com.example.crm.repository.InteractionRepository;

@ExtendWith(MockitoExtension.class)
class InteractionServiceTest {

    @Mock
    private InteractionRepository interactionRepository;

    @InjectMocks
    private InteractionService interactionService;

    private Interaction testInteraction;

    @BeforeEach
    void setUp() {
        testInteraction = new Interaction();
        testInteraction.setId(1L);
        testInteraction.setCustomerId(1L);
        testInteraction.setType("Call");
        testInteraction.setTopic("Product Inquiry");
        testInteraction.setNotes("Initial customer call");
    }

    @Test
    void getAllInteractions_ShouldReturnAllInteractions() {
        // Given
        List<Interaction> expectedInteractions = Arrays.asList(testInteraction);
        when(interactionRepository.findAll()).thenReturn(expectedInteractions);

        // When
        List<Interaction> actualInteractions = interactionService.getAllInteractions();

        // Then
        assertEquals(1, actualInteractions.size());
        assertEquals("Call", actualInteractions.get(0).getType());
        assertEquals("Product Inquiry", actualInteractions.get(0).getTopic());
        verify(interactionRepository).findAll();
    }

    @Test
    void getInteractionById_WhenInteractionExists_ShouldReturnInteraction() {
        // Given
        when(interactionRepository.findById(1L)).thenReturn(Optional.of(testInteraction));

        // When
        Interaction actualInteraction = interactionService.getInteractionById(1L);

        // Then
        assertNotNull(actualInteraction);
        assertEquals("Call", actualInteraction.getType());
        assertEquals("Product Inquiry", actualInteraction.getTopic());
        verify(interactionRepository).findById(1L);
    }

    @Test
    void getInteractionById_WhenInteractionDoesNotExist_ShouldReturnNull() {
        // Given
        when(interactionRepository.findById(999L)).thenReturn(Optional.empty());

        // When
        Interaction actualInteraction = interactionService.getInteractionById(999L);

        // Then
        assertNull(actualInteraction);
        verify(interactionRepository).findById(999L);
    }

    @Test
    void addInteraction_ShouldSaveInteraction() {
        // Given
        when(interactionRepository.save(any(Interaction.class))).thenReturn(testInteraction);

        // When
        interactionService.addInteraction(testInteraction);

        // Then
        verify(interactionRepository).save(testInteraction);
    }

    @Test
    void getInteractionsByCustomerId_ShouldReturnInteractionsForCustomer() {
        // Given
        List<Interaction> expectedInteractions = Arrays.asList(testInteraction);
        when(interactionRepository.findByCustomerId(1L)).thenReturn(expectedInteractions);

        // When
        List<Interaction> actualInteractions = interactionService.getInteractionsByCustomerId(1L);

        // Then
        assertEquals(1, actualInteractions.size());
        assertEquals(1L, actualInteractions.get(0).getCustomerId());
        verify(interactionRepository).findByCustomerId(1L);
    }

    @Test
    void deleteInteractionsByCustomerId_ShouldDeleteAllInteractionsForCustomer() {
        // When
        interactionService.deleteInteractionsByCustomerId(1L);

        // Then
        verify(interactionRepository).deleteByCustomerId(1L);
    }
}
