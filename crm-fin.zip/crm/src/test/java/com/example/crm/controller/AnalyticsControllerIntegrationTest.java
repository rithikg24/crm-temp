package com.example.crm.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

@SpringBootTest
@AutoConfigureWebMvc
@ActiveProfiles("test")
@Transactional
@Rollback(false)
class AnalyticsControllerIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void analytics_ShouldReturnAnalyticsView() throws Exception {
        mockMvc.perform(get("/analytics"))
                .andExpect(status().isOk())
                .andExpect(view().name("analytics"));
    }

    @Test
    void getCustomersOverTime_ShouldReturnJsonData() throws Exception {
        mockMvc.perform(get("/api/analytics/customers-over-time"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.labels").isArray())
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.labels").value(org.hamcrest.Matchers.hasSize(12)))
                .andExpect(jsonPath("$.data").value(org.hamcrest.Matchers.hasSize(12)));
    }

    @Test
    void getLeadsOverTime_ShouldReturnJsonData() throws Exception {
        mockMvc.perform(get("/api/analytics/leads-over-time"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.labels").isArray())
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.labels").value(org.hamcrest.Matchers.hasSize(12)))
                .andExpect(jsonPath("$.data").value(org.hamcrest.Matchers.hasSize(12)));
    }

    @Test
    void getCustomerTypes_ShouldReturnJsonData() throws Exception {
        // First create some customers with different types
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Individual Customer")
                .param("emailId", "individual@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Individual Address")
                .param("customerType", "Individual"));

        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Business Customer")
                .param("emailId", "business@example.com")
                .param("contactNumber", "0987654321")
                .param("address", "Business Address")
                .param("customerType", "Business"));

        // Then test the analytics endpoint
        mockMvc.perform(get("/api/analytics/customer-types"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.labels").isArray())
                .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    void getLeadStatus_ShouldReturnJsonData() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create some leads with different statuses
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "New lead"));

        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Referral")
                .param("status", "Closed Won")
                .param("topic", "Service Inquiry")
                .param("notes", "Closed lead"));

        // Then test the analytics endpoint
        mockMvc.perform(get("/api/analytics/lead-status"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.labels").isArray())
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.labels").value(org.hamcrest.Matchers.hasSize(2)));
    }

    @Test
    void getLeadSources_ShouldReturnJsonData() throws Exception {
        // First create a customer
        mockMvc.perform(post("/customers")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("name", "Test Customer")
                .param("emailId", "test@example.com")
                .param("contactNumber", "1234567890")
                .param("address", "Test Address")
                .param("customerType", "Individual"));

        // Then create some leads with different sources
        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Website")
                .param("status", "New")
                .param("topic", "Product Inquiry")
                .param("notes", "Website lead"));

        mockMvc.perform(post("/leads")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("customerType", "existing")
                .param("customerId", "1")
                .param("source", "Referral")
                .param("status", "New")
                .param("topic", "Service Inquiry")
                .param("notes", "Referral lead"));

        // Then test the analytics endpoint
        mockMvc.perform(get("/api/analytics/lead-sources"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.labels").isArray())
                .andExpect(jsonPath("$.data").isArray());
    }
}
