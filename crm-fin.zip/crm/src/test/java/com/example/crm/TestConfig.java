package com.example.crm;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Profile;

@TestConfiguration
@Profile("test")
public class TestConfig {
    // Test configuration for integration tests
    // Using real beans with H2 in-memory database
}
